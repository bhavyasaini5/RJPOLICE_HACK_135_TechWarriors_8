from django.apps import AppConfig


class MlAppConfig(AppConfig):
    name = 'ml_app'
